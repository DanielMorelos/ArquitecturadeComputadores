set_property SRC_FILE_INFO {cfile:C:/vivadopr/singlenexd4simtodo/singlenexd4simtodo.srcs/constrs_3/new/ppe_constraints.xdc rfile:../../../singlenexd4simtodo.srcs/constrs_3/new/ppe_constraints.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:1 export:INPUT save:INPUT read:READ} [current_design]
create_pblock pblock_1
resize_pblock [get_pblocks pblock_1] -add {SLICE_X0Y67:SLICE_X7Y74}
